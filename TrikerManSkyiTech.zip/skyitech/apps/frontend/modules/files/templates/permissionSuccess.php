<h2>You Can Download Files From Mobile</h2>
<div class="info">Sorry you can not download this file from computer, you must have to download from your mobile..
<br />visit <?php sfConfig::get('app_sitename')?> from your mobile...
</div>
<Br />