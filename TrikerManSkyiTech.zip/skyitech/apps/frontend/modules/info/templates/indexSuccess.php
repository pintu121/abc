<br />
<b>Dowload at your own Risk!</b><br/>
Please note, that we do not take any responsibility about the uploaded content.<br/>
If you found illegal files contact us or use the "Report Abuse" link at the bottom of each download page and we will remove this files.<br/>
To prevent any damages please download content only uploaded by your own.<br/>
Found some bugs or download problems please contact us too.<br />
<?php include(sfConfig::get('sf_upload_dir').'/advt/'.USERDEVICE.'_desclaimer.php'); ?>
<br />
