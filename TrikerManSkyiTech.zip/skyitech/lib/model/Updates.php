<?php

/**
 * Subclass for representing a row from the 'updates' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Updates extends BaseUpdates
{
}
