<?php

/**
 * Subclass for representing a row from the 'files' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Files extends BaseFiles
{
}
