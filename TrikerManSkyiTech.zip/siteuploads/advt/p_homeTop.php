<div class="devider"></div>
<div id="mainDiv">
	<div align="center"> <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).scroll(function(){
if($(document).scrollTop()>=$(document).height()/4)$("#finesticker").show("slow");
else $("#finesticker").hide("slow");});
function closeFBsticker(){$('#finesticker').remove();}
</script>
<style type="text/css">
/*
-----------------------------------------------
******* MirchiLoft.Com ******
	CSS Expert
	http://MirchiLoft.Com
	Copyrights © 2014 MirchiLoft.Com
----------------------------------------------- */

#finesticker {
    background: none repeat scroll 0 0 #F3F3F3;
    background-color: ;
    border-radius: 9px 9px 9px 9px;
    border: 1px solid #D7D7D7;
    bottom: 13px;
    display: none;
    padding: 12px 14px;
    position: fixed;
    right: 2px;
    width: 250px;
    z-index: 3;
}


</style>
<div><div id="finesticker" style="display: none;">
	<a onclick="return closeFBsticker();" href="javascript:void(0);" style="position:absolute;top:6px;right:8px;color:#555;font-size:10px;font-weight:bold;">(X)</a>
	<span style="font-size:14px;color:#000;font-weight:bold;float:left;">Like US for Latest Updates.</span>
<br/><br/>
<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fmirchiloftcom&width=250&height=500&colorscheme=light&show_faces=true&header=true&stream=false&show_border=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:250px; height:350px;" allowTransparency="true"></iframe>
</div>

</div> </div>
</div>

<center>
<a href="https://www.facebook.com/mirchiloftcom" target="_blank"><b>Like Our MirchiLoft Fan Page</b></a>
<iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fmirchiloftcom&width=90&layout=button_count&action=like&show_faces=false&share=false&height=21&appId=273139206174468" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:90px; height:21px;" allowTransparency="true"></iframe></center>






<script type="text/javascript">
marqueeInit({
	uniqueid: 'mycrawler2',
	style: {
		'padding': '2px',
		'width': '1500px',
		'margin': '0 auto',
		'height': '150px'
	},
	inc: 5, //speed - pixel increment for each iteration of this marquee's movement
	mouse: 'cursor driven', //mouseover behavior ('pause' 'cursor driven' or false)
	moveatleast: 2,
	neutral: 150,
	savedirection: true,
	random: true
});
</script></div>