<h2><center>::.. Disclaimer ..::</center></h2>
<br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› Please Read The Disclaimer Before Download Anything From MirchiLoft.Com</b></div><br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› This is a promotional WAPSITE only, All files placed here are for introducing purpose only.</b></div><br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› Please, buy original Video Songs/contents from author or developer site!</b></div><br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› If you do not agree to all the terms, please disconnect from this site now itself.</b></div><br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› By remaining at this site, you affirm your understanding and compliance of the above disclaimer and absolve this site of any responsibility henceforth</b></div><br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› All files found on this site have been collected from various sources across the web and are believed to be in the "public domain".</b></div><br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› All the logos and stuff are the property of their respective owners</b></div><br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› If you are the rightful owner of any contents posted here, and object to them being displayed or If you are one of representativities of copy rights department and you dont like our conditions of store, Please Contact Us We will remove it in 24 hour!</b></div><br/>
<div  style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› Downloading at your own risk!!! </b></div><br/>
<a href="http://www.automaticbacklinks.com/">Automatic Backlinks</a>

                            